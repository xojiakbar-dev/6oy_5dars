from django.urls import path
from .views import home,course_list, student_list, course_students, student_detail

urlpatterns = [
    path('', home, name='home'),
    path('courses/', course_list, name='course_list'),
    path('students/', student_list, name='student_list'),
    path('courses/<int:course_id>/', course_students, name='course_students'),
    path('students/<int:student_id>/', student_detail, name='student_detail'),
]