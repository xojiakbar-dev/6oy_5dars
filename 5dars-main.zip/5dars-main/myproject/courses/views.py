from django.shortcuts import render, get_object_or_404
from .models import Course, Student


def home(request):
    return render(request, 'home.html')

def course_list(request):
    courses = Course.objects.all()
    students = Student.objects.all()
    return render(request, 'course_list.html', {'courses': courses, 'students': students})

def student_list(request):
    students = Student.objects.all()
    return render(request, 'student_list.html', {'students': students})

def course_students(request, course_id):
    course = Course.objects.get(id=course_id)
    students = course.students.all()
    return render(request, 'course_students.html', {'course': course, 'students': students})

def student_detail(request, student_id):
    student = Student.objects.get( id=student_id)
    return render(request, 'student_detail.html', {'student': student})